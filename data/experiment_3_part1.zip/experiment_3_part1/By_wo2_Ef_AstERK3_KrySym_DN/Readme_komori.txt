The results were obtaind for m=100 if the name of subfolder
does not identify the value of m.
(26-Mar-2023)